﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Uber.Models
{
    public class Time
    {
        public string product_id { get; set; }
        public string display_name { get; set; }
        public int estimate { get; set; }
    }
}
