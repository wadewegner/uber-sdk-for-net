﻿namespace Uber.Models
{
    public class User
    {
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public string picture { get; set; }
        public string promo_code { get; set; }
    }
}
